#!/bin/bash
# USB OTG OFF / DESLIGADA (original) - switches the DTB used at boot and reboots / troca o DTB do boot e reinicia.
TARGET="rk3326-rg351mp-linux.dtb"
if sudo -n true 2>/dev/null; then S() { sudo "$@"; }; else S() { echo ark | sudo -S -p '' "$@"; }; fi
msg() { printf "\n\n%s\n" "$1" > /dev/tty1 2>/dev/null; }
if [ ! -f "/boot/$TARGET" ]; then
  msg "ERROR/ERRO: /boot/$TARGET not found / nao encontrado. Nothing changed / Nada foi alterado."
  sleep 6; exit 1
fi
[ -f /boot/boot.ini.before-otg-fix ] || S cp /boot/boot.ini /boot/boot.ini.before-otg-fix
S sed -i -E 's#^(load mmc 1:1 [^ ]+ ).*[.]dtb[[:space:]]*$#\1'"$TARGET"'#' /boot/boot.ini
if ! grep -q "$TARGET" /boot/boot.ini; then
  msg "ERROR/ERRO: could not edit boot.ini / nao consegui alterar o boot.ini."
  sleep 6; exit 1
fi
S sync
msg "USB OTG OFF / DESLIGADA (original) - rebooting / reiniciando..."
sleep 3
S reboot
