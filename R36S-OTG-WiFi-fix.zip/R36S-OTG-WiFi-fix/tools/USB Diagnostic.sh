#!/bin/bash
# Diagnostico USB/OTG para R36S (ArkOS) - gera um log na mesma pasta deste script.
# Tambem tenta forcar a porta OTG para modo "host" e registra o antes/depois.

DIR="$(cd "$(dirname "$0")" && pwd)"
LOG="$DIR/usb-log-$(date +%Y%m%d-%H%M%S).txt"

if sudo -n true 2>/dev/null; then
  S() { sudo "$@"; }
else
  S() { echo ark | sudo -S -p '' "$@"; }
fi

sec() { echo; echo "===================== $1 ====================="; }
run() { echo "\$ $*"; S bash -c "$*" 2>&1; echo; }

{
  sec "SISTEMA"
  run "date; uname -a"
  run "tr -d '\0' < /proc/device-tree/model; echo"
  run "cat /proc/cmdline"
  run "cat /etc/os-release 2>/dev/null | head -5"
  run "ls -la /boot 2>/dev/null"

  S mount -t debugfs none /sys/kernel/debug 2>/dev/null

  sec "STATUS NO DEVICE TREE CARREGADO"
  run "for f in /proc/device-tree/syscon@ff2c0000/usb2-phy@100/otg-port/status /proc/device-tree/syscon@ff2c0000/usb2-phy@100/host-port/status /proc/device-tree/usb@ff300000/status /proc/device-tree/usb@ff300000/dr_mode; do echo \"\$f: \$(tr -d '\0' < \$f 2>/dev/null)\"; done"
  run "ls /proc/device-tree/i2c@ff180000/pmic@20/regulators/OTG_SWITCH/ 2>/dev/null"

  sec "USB ANTES"
  run "lsusb 2>/dev/null || echo 'lsusb indisponivel'"
  run "lsusb -t 2>/dev/null"
  run "ls -la /sys/bus/usb/devices/"
  run "cat /sys/kernel/debug/usb/devices 2>/dev/null"

  sec "PHY / MODO OTG"
  run "find /sys/devices/platform -maxdepth 3 -iname '*usb2-phy*' -o -maxdepth 3 -iname '*ff2c0000*' 2>/dev/null"
  run "for f in \$(find /sys/devices/platform -name otg_mode 2>/dev/null); do echo \"\$f = \$(cat \$f)\"; done"
  run "for f in \$(find /sys/class/usb_role -name role 2>/dev/null); do echo \"\$f = \$(cat \$f)\"; done"
  run "ls /sys/kernel/debug/ 2>/dev/null; ls /sys/kernel/debug/ff300000.usb 2>/dev/null"
  run "cat /sys/kernel/debug/ff300000.usb/dr_mode 2>/dev/null; cat /sys/kernel/debug/ff300000.usb/state 2>/dev/null | head -40"

  sec "REGULADORES (energia)"
  run "for r in /sys/class/regulator/regulator.*; do echo \"\$(cat \$r/name 2>/dev/null) | state=\$(cat \$r/state 2>/dev/null) | uV=\$(cat \$r/microvolts 2>/dev/null) | users=\$(cat \$r/num_users 2>/dev/null)\"; done"
  run "cat /sys/kernel/debug/regulator/regulator_summary 2>/dev/null"

  sec "EXTCON / CARREGADOR"
  run "for e in /sys/class/extcon/*; do echo \"\$e: \$(cat \$e/name 2>/dev/null) -> \$(cat \$e/state 2>/dev/null)\"; done"
  run "for p in /sys/class/power_supply/*; do echo \"\$p\"; cat \$p/uevent 2>/dev/null; done"

  sec "MODULOS / DRIVERS"
  run "lsmod 2>/dev/null"
  run "ls /lib/modules/\$(uname -r)/kernel/drivers/net/wireless 2>/dev/null; find /lib/modules/\$(uname -r) -iname '*8188*' -o -iname '*rtl8xxxu*' -o -iname '*mt7601*' 2>/dev/null"
  run "zcat /proc/config.gz 2>/dev/null | grep -E 'CONFIG_USB_DWC2|CONFIG_USB_EHCI|CONFIG_USB_OHCI|CONFIG_USB_HID|CONFIG_HID_GENERIC|CONFIG_USB_STORAGE|CONFIG_PHY_ROCKCHIP_INNO_USB2|CONFIG_RTL8188|CONFIG_RTL8XXXU|CONFIG_MT7601'"

  sec "REDE"
  run "ip link 2>/dev/null; iw dev 2>/dev/null; rfkill list 2>/dev/null"

  sec "DMESG USB (antes)"
  run "dmesg | grep -iE 'usb|dwc2|otg|phy|vbus|hid|8188|rtl|wlan|regulator|otg_switch|extcon' | tail -200"

  sec "TENTATIVA: FORCAR MODO HOST"
  for f in $(find /sys/devices/platform -name otg_mode 2>/dev/null); do
    echo "Escrevendo 'host' em $f"
    echo host | S tee "$f" 2>&1
  done
  for f in $(find /sys/class/usb_role -name role 2>/dev/null); do
    echo "Escrevendo 'host' em $f"
    echo host | S tee "$f" 2>&1
  done
  echo "Aguardando 8 segundos..."
  sleep 8

  sec "USB DEPOIS"
  run "for f in \$(find /sys/devices/platform -name otg_mode 2>/dev/null); do echo \"\$f = \$(cat \$f)\"; done"
  run "lsusb 2>/dev/null"
  run "ls -la /sys/bus/usb/devices/"
  run "ip link 2>/dev/null"

  sec "DMESG COMPLETO (ultimas 400 linhas)"
  run "dmesg | tail -400"

  echo; echo "FIM DO LOG"
} > "$LOG" 2>&1

sync
printf "\n\nLog salvo em:\n%s\n" "$LOG" > /dev/tty1 2>/dev/null
sleep 3
