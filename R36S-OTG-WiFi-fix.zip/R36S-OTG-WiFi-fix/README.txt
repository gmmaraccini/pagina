R36S - USB OTG + Wi-Fi (RTL8188FTV) fix
=======================================
(Portugues abaixo / Portuguese below)

WHO THIS IS FOR
- R36S with ArkOS 2.0 based image (tested: unit sold by "Oasis Market",
  "ArkOS 2.0 (07312025)", EmulationStation V2.13.0.0 CHMOD BUILD).
- Kernel 4.4.189.
- BOOT partition uses rk3326-rg351mp-linux.dtb with internal model
  "Game Console R35S/R36S fix by lxc".
- Symptom: Wi-Fi status "Off", Wi-Fi list empty, and NOTHING works on the
  OTG port (no keyboard, no USB stick), even with known-good adapters.

ROOT CAUSE (in the stock DTB)
1. otg-port PHY (syscon@ff2c0000/usb2-phy@100/otg-port) status = "disabled"
2. usb@ff300000 dr_mode = "otg" (never switches to host)
3. OTG_SWITCH regulator (5V to the port) has no regulator-always-on,
   so the port never gets power.
The fixed DTB changes ONLY these 3 things:
   otg-port status -> "okay", dr_mode -> "host",
   OTG_SWITCH -> regulator-always-on.
Changing only 1 and 2 is NOT enough (tested).

SECOND PROBLEM: the image has no driver for RTL8188FTV (USB ID 0bda:f179).
Fix: free XNL driver installer (see step 3).

BACK UP YOUR SD CARD FIRST.

STEP 1 - copy the DTB
  Copy BOOT/rk3326-rg351mp-linux-otg-fix.dtb to the BOOT partition
  of the OS card. Do NOT delete rk3326-rg351mp-linux.dtb.

STEP 2 - enable it (pick one)
  a) Copy the files in tools/ to EASYROMS/tools, boot the console and
     run Settings > Tools > "USB-OTG ON". It edits boot.ini and reboots.
  b) Or edit boot.ini on the PC: change the line
       load mmc 1:1 ${dtb_loadaddr} rk3326-rg351mp-linux.dtb
     to
       load mmc 1:1 ${dtb_loadaddr} rk3326-rg351mp-linux-otg-fix.dtb
     (do NOT copy someone else's boot.ini - it contains your card UUID)

STEP 3 - Wi-Fi driver for RTL8188FTV dongles
  https://www.teamxnl.com/product/r36-rtl8188ftv-driver/
  IMPORTANT: create an account and LOG IN before "I Agree & Add to
  download basket" + checkout. As a guest the order had no e-mail and
  the link returned "Invalid download link".
  Extract the zip, copy the folder "XNL RTL8188FTV" to EASYROMS/tools,
  then Settings > Tools > XNL RTL8188FTV > Install Driver, reboot with
  the dongle plugged in, open Wifi.
  (Dongles with MT7601U / RTL8188EUS / RTL8192CU already have drivers.)

TO UNDO
  Run "USB-OTG OFF (original)" or, on the PC, rename
  boot.ini.before-otg-fix to boot.ini.

NOTES
- With the 5V always on there is a small extra battery drain. Unplug the
  dongle when not using it, or use "USB-OTG OFF".
- OTG port works only as host (no PC data mode on that port).
- "USB Diagnostic" writes a log to the same folder. Remove your dongle
  MAC / serial before sharing it.
- A wrong DTB for your board can give a black screen: restore
  boot.ini.before-otg-fix on the PC.
- Use at your own risk.

---------------------------------------------------------------------

PORTUGUES

PARA QUEM E
- R36S com imagem baseada no ArkOS 2.0 (testado: vendido pela "Oasis
  Market", "ArkOS 2.0 (07312025)"), kernel 4.4.189, DTB
  rk3326-rg351mp-linux.dtb com modelo "Game Console R35S/R36S fix by lxc".
- Sintoma: Wi-Fi "Off", lista de redes vazia e nada funciona na porta
  OTG (nem teclado, nem pendrive), mesmo com adaptador bom.

CAUSA (no DTB original)
1. PHY da porta OTG desligada ("disabled")
2. Porta em modo "otg" (nao vira host)
3. Energia 5V da porta (OTG_SWITCH) nao fica ligada
O DTB corrigido muda so essas 3 coisas. Corrigir so 1 e 2 NAO resolve.

SEGUNDO PROBLEMA: o sistema nao tem driver do RTL8188FTV (0bda:f179).

FACA BACKUP DO CARTAO ANTES.

PASSO 1 - copie BOOT/rk3326-rg351mp-linux-otg-fix.dtb para a particao
  BOOT. Nao apague o rk3326-rg351mp-linux.dtb.

PASSO 2 - ative (escolha um)
  a) Copie os arquivos de tools/ para EASYROMS/tools, ligue o console e
     rode Settings > Tools > "USB-OTG ON". Ele altera o boot.ini e reinicia.
  b) Ou edite o boot.ini no PC, trocando a linha
       load mmc 1:1 ${dtb_loadaddr} rk3326-rg351mp-linux.dtb
     por
       load mmc 1:1 ${dtb_loadaddr} rk3326-rg351mp-linux-otg-fix.dtb
     (nao use o boot.ini de outra pessoa - ele tem o UUID do cartao)

PASSO 3 - driver Wi-Fi do RTL8188FTV
  https://www.teamxnl.com/product/r36-rtl8188ftv-driver/
  IMPORTANTE: crie uma conta e FACA LOGIN antes de clicar em
  "I Agree & Add to download basket" e finalizar. Sem login o pedido
  fica sem e-mail e o link da "Invalid download link". E gratuito.
  Extraia o zip, copie a pasta "XNL RTL8188FTV" para EASYROMS/tools,
  va em Settings > Tools > XNL RTL8188FTV > Install Driver, reinicie
  com o dongle plugado e abra Wifi.

DESFAZER
  Rode "USB-OTG OFF (original)" ou, no PC, renomeie
  boot.ini.before-otg-fix para boot.ini.

OBSERVACOES
- Com os 5V sempre ligados, gasta um pouco mais de bateria. Tire o
  dongle quando nao usar, ou use "USB-OTG OFF".
- A porta OTG passa a funcionar so como host.
- "USB Diagnostic" gera um log na mesma pasta. Apague o MAC/serial do
  dongle antes de compartilhar.
- DTB errado para a sua placa pode deixar a tela preta: restaure o
  boot.ini.before-otg-fix no PC.
- Use por sua conta e risco.
